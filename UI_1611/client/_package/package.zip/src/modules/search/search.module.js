/*
*	JS for initializing angular module container.
*   Defining controller, model, service for Search/Home functionality.
*/

'use strict';


// Home/Screen screen has been wrapped up inside 'searchModule' module
angular.module('searchModule', []);