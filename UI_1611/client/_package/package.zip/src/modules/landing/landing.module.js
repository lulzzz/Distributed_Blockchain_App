/*
*	JS for initializing angular module container.
*   Defining controller, model, service for User functionality.
*/

'use strict';


// User login and session functionality has been wrapped up inside 'userModule' module
angular.module('landingModule', []);