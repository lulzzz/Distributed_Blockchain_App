/*
*	JS for initializing angular module container.
*   Defining controller, model, service for Product functionality.
*/

'use strict';


//All Product screen functionality has been wrapped up inside 'dashboardModule' module
angular.module('dashboardModule', []);