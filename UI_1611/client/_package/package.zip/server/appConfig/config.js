var config = {};

config.AWS_ACCESSKEY = "AKIAJ2YVOM4ZXQ5GKSNQ";
config.AWS_SECRETACCESSKEY = "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";
config.S3_ENDPOINT = "s3-eu-central-1.amazonaws.com";
config.S3_VERSION = "v4";
config.S3_REGION = "eu-central-1";
config.S3_BUCKET = "bverifybucket";



module.exports = config;